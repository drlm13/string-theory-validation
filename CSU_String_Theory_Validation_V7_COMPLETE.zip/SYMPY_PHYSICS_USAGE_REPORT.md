# SymPy Physics Usage Report

## Modules Used
| Module | Purpose |
|--------|---------|
| `sympy.core` | Symbolic algebra, Rational arithmetic |
| `sympy.functions` | zeta, log, exp, sqrt, trig |
| `sympy.matrices` | SL(2,Z) generators, Virasoro matrices |
| `sympy.solvers` | Critical dimension equations |
| `sympy.calculus` | Derivatives for spectral dimension |
| `sympy.physics.quantum` | Operator, Commutator, AntiCommutator, Dagger |
| `sympy.physics.quantum.hilbert` | ComplexSpace, FockSpace |
| `sympy.physics.secondquant` | B, Bd, BKet (creation/annihilation) |
| `sympy.physics.units` | hbar, c, G |
| `sympy.physics.wigner` | Wigner 3j, 6j symbols |
| `sympy.diffgeom` | Manifold, Patch, CoordSystem |

## Key Computations
- ζ(-1) = -1/12 (exact, via sympy.zeta)
- Ghost central charges via polynomial evaluation
- SL(2,Z) matrix algebra (S, T generators)
- Virasoro central extension terms
- Super-Virasoro anticommutator central terms
- Heat kernel spectral dimension via symbolic differentiation
- T-duality mass spectrum invariance
- Weyl tensor component counting
- Calabi-Yau Euler characteristic
