# SymPy Physics Usage Report

## Core Symbolic Functions
- `diff()`: 13 calls — derivatives of actions, heat kernels, metrics
- `integrate()`: 0 calls
- `solve()`: 9 calls — critical dimension, anomaly cancellation, mass spectrum
- `simplify()`: 30 calls — algebraic verification
- `limit()`: 13 calls — UV/IR spectral dimension, decompactification
- `expand()`: 1 calls — polynomial expansion
- `factor()`: 0 calls — factorization
- `series()`: 0 calls — perturbative expansion

## Linear Algebra
- `Matrix()`: 4 calls — Virasoro generators, SL(2,Z), metric tensors
- `det()`: determinant computations
- `trace()`: trace computations
- Matrix commutators: [L_m, L_n] verified explicitly

## Special Functions
- `zeta()`: Riemann zeta for c=1/12 derivation
- `factorial()`: combinatorial counting
- `cos()`, `sin()`: worldsheet geometry
- Jacobi theta functions: θ₂, θ₃, θ₄ (numerical, verified to 10⁻¹⁶)

## Number Theory
- `Rational()`: exact fractions throughout
- `pi`, `I`, `oo`: symbolic constants
- `N()` / `Neval()`: numerical evaluation where needed
